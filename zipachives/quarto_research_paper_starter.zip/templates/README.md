# Templates
Place your Word reference document here, e.g. `journal-reference.docx`, which encodes styles
(Title, Authors, Affiliations, Abstract, Heading 1–3, Figure title, Table title, References).
Then point `_quarto.yml -> format: docx -> reference-doc` at this file.
